-- MySQL dump 10.13  Distrib 8.0.13, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: demo
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `table2`
--

DROP TABLE IF EXISTS `table2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `table2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_name` varchar(64) DEFAULT NULL,
  `first_name` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `department` varchar(64) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `resume` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table2`
--

LOCK TABLES `table2` WRITE;
/*!40000 ALTER TABLE `table2` DISABLE KEYS */;
INSERT INTO `table2` VALUES (2,'Public','Mary','mary.public@foo.com','Engineering',300000.00,'John Doe\nFull Address - City, State, ZIP - Phone Number - E-mail\n\nOBJECTIVE: Design apparel print for an innovative retail company \n\nEDUCATION:\nUNIVERSITY OF MINNESOTA\n- College of Design\n- Bachelor of Science in Graphic Design\n- Cumulative GPA 3.93, Dean’s List\n- Twin cities Iron Range Scholarship\n\nWORK EXPERIENCE:\nAMERICAN EAGLE\nSales Associate\nCity, State May 2011\n- Collaborated with the store merchandiser creating displays to attract clientele \n- Use my trend awareness to assist customers in their shopping experience\n- Thoroughly scan every piece of merchandise for inventory control\n- Process shipment to increase my product knowledge\n\nPLANET BEACH\nSpa Consultant\nCity, State July 2009 - present\n- Sell retail and memberships to meet company sales goals\n- Build organizational skills by single handedly running all operating procedures - Communicate with clients to fulfill their wants and needs\n- Attend promotional events to market our services\n- Handle cash and deposits during opening and closing\n- Received employee of the month award twice\n\nHEARTBREAKER,\nSales Associate\nCity, State Aug. 2008 - present\n- Stocked sales floor with fast fashion inventory\n- Marked down items allowing me to see unsuccessful merchandise in a retail market - Offered advice and assistance to each guest\n\nVICTORIA’S SECRET\nFashion Representative\nCity, State May 2008 – Aug. 2008\n- Applied my leadership skills by assisting in the training of coworkers\n- Set up mannequins and displays in order to entice future customers\n- Provided superior customer service by helping with consumer decisions - Took seasonal inventory\n\nVOLUNTEER EXPERIENCE:\nTARGET CORPORATION\nBrand Ambassador\nCity, State August 2009\n- Represented Periscope Marketing and Target Inc. at a college event\n- Engaged University of Minnesota freshman in the Target brand experience\n'),(3,'Queue','Susan','susan.queue@foo.com','Legal',130000.00,NULL),(5,'Johnson','Lisa','lisa.johnson@foo.com','Engineering',300000.00,NULL),(6,'Smith','Paul','paul.smith@foo.com','Legal',100000.00,NULL),(8,'Brown','Bill','bill.brown@foo.com','Engineering',300000.00,NULL),(9,'Thomas','Susan','susan.thomas@foo.com','Legal',80000.00,NULL),(11,'Fowler','Mary','mary.fowler@foo.com','Engineering',300000.00,NULL),(12,'Waters','David','david.waters@foo.com','Legal',90000.00,NULL);
/*!40000 ALTER TABLE `table2` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-24 13:30:21
